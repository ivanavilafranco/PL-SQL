CREATE OR REPLACE FUNCTION factorial (n INTEGER) RETURN INTEGER IS
BEGIN
  IF n < 0 THEN
      DBMS_OUTPUT.PUT_LINE('No se consideran valores negativos para el c�lculo del factorial');
      RETURN -1;
  ELSE
    IF n > 33 THEN
      DBMS_OUTPUT.PUT_LINE('No se consideran valores SUPERIORES a 33 para el c�lculo del factorial');
      RETURN 0;
    ELSE
      IF  (n = 1) OR (n = 0) THEN 
        RETURN 1;
      ELSE
        RETURN n * factorial (n - 1);
      END IF;
    END IF;
  END IF;
END factorial;
