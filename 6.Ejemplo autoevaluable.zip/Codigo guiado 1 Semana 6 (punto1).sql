CREATE OR REPLACE PROCEDURE DIVISION (dividendo IN NUMBER, divisor IN NUMBER) IS
		Resultado			NUMBER;
		Valores_negativos	EXCEPTION;
BEGIN
		If (dividendo < 0) or (divisor < 0) then
			RAISE valores_negativos;
		Else
			Resultado := dividendo / divisor;
		End if;
		DBMS_OUTPUT.PUT_LINE('El resultado de la divisi�n es: '||resultado);
EXCEPTION
		WHEN ZERO_DIVIDE THEN
			DBMS_OUTPUT.PUT_LINE('N�mero de error ORACLE: '||sqlcode);
			DBMS_OUTPUT.PUT_LINE('El mensaje de error ORACLE es: '||sqlerrm);
			DBMS_OUTPUT.PUT_LINE('El valor del dividendo es: '||dividendo);
			DBMS_OUTPUT.PUT_LINE('El valor del divisor es: '||divisor);
		WHEN valores_negativos THEN
			DBMS_OUTPUT.PUT_LINE('Los valores introducidos para el dividendo: '||dividendo||' o divisor: '||divisor||' son negativos.');
END;
