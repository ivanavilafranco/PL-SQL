SET SERVEROUTPUT ON
DECLARE
   num_empleados    NUMBER(2);
BEGIN
   SUPUESTO6('B','T',num_empleados);
END;
