create or replace package supuesto8 is
	function factorial(n POSITIVE) return INTEGER;
	function ptas_euros(n NUMBER) return NUMBER;
	function euros_ptas(n NUMBER) return  NUMBER;
	function num_carac (n NUMBER) return VARCHAR2;
	conversion	CONSTANT NUMBER(6,3) := 166.386;
end supuesto8;
/
create or replace package body supuesto8 is
FUNCTION factorial (n POSITIVE) RETURN INTEGER IS 
BEGIN
	IF (n = 1) or (n = 0)THEN
		RETURN 1;
	ELSE
		RETURN n * factorial (n - 1);
	END IF;
END factorial;

FUNCTION ptas_euros (n NUMBER) RETURN NUMBER IS
BEGIN
	RETURN ROUND(n / conversion,2);
END ptas_euros;

FUNCTION euros_ptas (n NUMBER) RETURN NUMBER IS
BEGIN
		RETURN ROUND(n * conversion,0);
END euros_ptas;

FUNCTION num_carac(n NUMBER) RETURN VARCHAR2 IS
BEGIN
		RETURN TO_CHAR(n,'9G999G999D999');
END num_carac;
END supuesto8;
/